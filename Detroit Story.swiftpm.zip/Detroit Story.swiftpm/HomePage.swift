//
//  File.swift
//  Detroit Story
//
//  Created by Nick Gordon on 9/16/22.
//

//import Foundation
import SwiftUI

struct Podiums: Identifiable {
    var name: String
    var image: String
    var id = UUID()
    var view: AnyView
}

private var podiumList = [
    Podiums(name: "Architecture", image: "Podium", view: AnyView(ArchitecturePage())),
    Podiums(name: "Food",image: "Podium", view: AnyView(FoodPage())),
    Podiums(name: "Automobiles", image: "Podium", view: AnyView(AutomobilePage())),
    Podiums(name: "Art", image: "Podium", view: AnyView(ArtPage()))
    
]

struct podiumLayout:View {
    var podiums = Podiums(name: "yo", image: "Podium", view: AnyView(ArtPage()))
    
    
    var body: some View {
        
        
        VStack {
            NavigationLink(destination: podiums.view) {
                Text(podiums.name)
            }
            Image(podiums.image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 350, height: 200)
            
        }
    }
    
}

struct HomePage: View {
    var body: some View {
        NavigationView{
            VStack {
                Text("Choose your Experience")
                ScrollView(.horizontal) {
                    LazyHStack {
                        ForEach(podiumList) { Podiums
                            in podiumLayout(podiums: Podiums)
                        }
                    }
                }
            }
            
        }
    }
}

struct HomePage_Previews: PreviewProvider {
    static var previews: some View {
        HomePage()
    }
}



