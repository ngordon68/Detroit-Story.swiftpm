//
//  File.swift
//  Detroit Story
//
//  Created by Nick Gordon on 9/16/22.
//

import Foundation
import SwiftUI

struct AutomobilePage: View {
    var body: some View {
        ZStack {
            Color.pink
        VStack {
            Text("This page is for Automobile stuff")
            
            
        }
    }
    }
}

struct Automobile_Previews: PreviewProvider {
    static var previews: some View {
        AutomobilePage()
    }
}
