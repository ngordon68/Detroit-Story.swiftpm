//
//  File.swift
//  Detroit Story
//
//  Created by Nick Gordon on 9/16/22.
//

import Foundation
import SwiftUI

struct ArtPage: View {
    var body: some View {
        ZStack {
            Color.pink
        VStack {
            Text("This page is for Art stuff")
            
            
        }
    }
    }
}

struct ArtPage_Previews: PreviewProvider {
    static var previews: some View {
        ArtPage()
    }
}
